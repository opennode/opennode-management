# Make enum implementations available for direct import.
# HashEnum is considered the default implementation and loaded as such.
from enum import HashEnum as Enum
from enum import ValueEnum 